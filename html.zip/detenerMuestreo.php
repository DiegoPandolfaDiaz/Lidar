<?php
session_start();
$_SESSION['muestreo']=0;
/*system("python muestreo.py");*/
header("Location: /index.php");
  ?>