import sys
import serial
counter=0;
try:
	ser=ser = serial.Serial(
    port='/dev/ttyACM0', 
    baudrate=9600, 
    timeout=1,
    parity=serial.PARITY_NONE,
    stopbits=serial.STOPBITS_ONE,
    bytesize=serial.EIGHTBITS
)
	while (counter<50):
		counter+=1;
		ser.reset_input_buffer();
		imput=ser.read(4);
		#ser.reset_input_buffer();
		#print(imput.decode("utf-8"))
		if(imput):
			sys.stdout.write(" <span class='label-success label label-default'> conectado</span>\n")
			break
	else:
		sys.stdout.write("</strong> <span class='label-default label label-danger'>Error2</span>\n");
except:
	sys.stdout.write("</strong> <span class='label-default label label-danger'>Error1 </span>\n")
