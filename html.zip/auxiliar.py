#!/usr/bin/python3
import _thread
import os
import time

# Define a function for the thread
#def print_time( threadName, delay):
import subprocess
stdoutdata = subprocess.getoutput("python muestreo.py")

